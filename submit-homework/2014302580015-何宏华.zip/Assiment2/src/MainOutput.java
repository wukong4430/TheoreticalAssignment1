import jxl.*;
import java.io.File;
import jxl.write.*;
public class MainOutput {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		public void processScoreTable(File "test.xls"){ 
		File file1 = new File("test.xls");
		try {
			Workbook wb1 = Workbook.getWorkbook(file1);
			WritableWorkbook book = 
					Workbook.createWorkbook(new File("test.xls"),wb1);
			WritableSheet sheet1 = book.getSheet(0);
			double sum = 0;
			double xuefen = 0;
			double GPA = 0;
			double GPA1 = 0;
			double ReallyGpa = 0;
			for(int k = 1;k<23; k++){
				Cell cell1 = sheet1.getCell(3,k);
				Cell cell2 = sheet1.getCell(9,k);
				String S1 = cell1.getContents();
				String S2 = cell2.getContents();
				double I1 = Double.parseDouble(S1);//���ɼ����double���ͷ��������һ���Ƚ�
			    double I2 = Double.parseDouble(S2); 
			    if(I2 >= 90) GPA = 4.0;
				else if(I2 >= 85) GPA = 3.7;
				else if(I2 >= 82) GPA = 3.3;
				else if(I2 >= 78) GPA = 3.0;
				else if(I2 >= 75) GPA = 2.7;
				else if(I2 >= 72) GPA = 2.3;
				else if(I2 >= 68) GPA = 2.0;
				else if(I2 >= 64) GPA = 1.5;
				else if(I2 >= 60) GPA = 1.0;
				else GPA = 0;
			    GPA1 = GPA1+GPA*I1;
			    sum = sum+I1*I2;
			    xuefen = xuefen+I1;
			    ReallyGpa = GPA1/xuefen;
			    double jiaquan = sum/xuefen;
			    String t = String.valueOf(jiaquan);
			    String a = String.valueOf(ReallyGpa);
					sheet1.addCell(new Label(10,1,t));
					sheet1.addCell(new Label(10,0,"��Ȩƽ����"));
					sheet1.addCell(new Label(11,0,"��ȨGPA"));
					sheet1.addCell(new Label(11,1,a));
					
			}
			book.write();
			book.close();
			wb1.close();
			}
				 catch (Exception e) {
					// TODO �Զ����ɵ� catch ��
					e.printStackTrace();
				
			}
	}
	}
}
